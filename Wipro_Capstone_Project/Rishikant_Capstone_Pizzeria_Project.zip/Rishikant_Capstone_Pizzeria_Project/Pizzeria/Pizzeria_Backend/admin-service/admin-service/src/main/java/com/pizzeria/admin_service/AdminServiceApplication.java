package com.pizzeria.admin_service;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.pizzeria.admin_service.entity.Admin;
import com.pizzeria.admin_service.repository.AdminRepository;

@SpringBootApplication
public class AdminServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminServiceApplication.class, args);
	}

	 @Bean
	    CommandLineRunner init(AdminRepository repo) {
	        return args -> {

	            if (repo.count() == 0) {

	                Admin admin = new Admin();

	                admin.setName("Admin");
	                admin.setEmail("admin@pizza.com");
	                admin.setPassword("admin123");

	                repo.save(admin);

	                System.out.println("Default Admin Created");
	            }
	        };
	    }
}
