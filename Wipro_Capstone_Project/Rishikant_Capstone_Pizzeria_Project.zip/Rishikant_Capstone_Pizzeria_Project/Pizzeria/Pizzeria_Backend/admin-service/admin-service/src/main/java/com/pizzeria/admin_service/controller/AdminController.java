package com.pizzeria.admin_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.pizzeria.admin_service.dto.AdminLoginDto;
import com.pizzeria.admin_service.dto.MenuItemDto;
import com.pizzeria.admin_service.entity.Category;
import com.pizzeria.admin_service.entity.MenuItem;
import com.pizzeria.admin_service.entity.UserDetails;
import com.pizzeria.admin_service.service.AdminService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

@RestController
@RequestMapping("/admin")
@Validated
public class AdminController {

    @Autowired
    AdminService service;

    @PostMapping("/login")
    public String login(
            
            @RequestBody AdminLoginDto dto) {

        return service.adminLogin(dto);
    }

    @PostMapping("/menu")
    public String addMenu(
            @Valid
            @RequestBody MenuItemDto dto) {

        return service.addMenuItem(dto);
    }

    @GetMapping("/menu")
    public List<MenuItem> getAllMenu() {

        return (List<MenuItem>)
                service.getAllMenuItems();
    }

    @PutMapping("/menu/{id}")
    public ResponseEntity<MenuItem> updateMenuItem(
            @PathVariable
            @Positive(message = "Menu item id must be positive")
            Long id,

            @Valid
            @RequestBody MenuItem menuItem) {

        return ResponseEntity.ok(
                service.updateMenuItem(id, menuItem)
        );
    }

    @DeleteMapping("/menu/{id}")
    public String deleteMenu(
            @PathVariable
            @Positive(message = "Menu item id must be positive")
            Long id) {

        return service.deleteMenuItem(id);
    }

    @GetMapping("/menu/category/{category}")
    public List<MenuItem> searchCategory(
            @PathVariable Category category) {

        return service.searchByCategory(category);
    }

    @GetMapping("/menu/search")
    public List<MenuItem> searchName(
            @RequestParam
            @NotBlank(message = "Search name cannot be empty")
            String name) {

        return service.searchByName(name);
    }

    @PutMapping("/orders/{orderId}/accept")
    public String acceptOrder(
            @PathVariable
            @Positive(message = "Order id must be positive")
            Long orderId) {

        return service.acceptOrder(orderId);
    }

    @PutMapping("/orders/{orderId}/reject")
    public String rejectOrder(
            @PathVariable
            @Positive(message = "Order id must be positive")
            Long orderId) {

        return service.rejectOrder(orderId);
    }

    @PutMapping("/{token}")
    public String setUserAuthToken(
            @Valid
            @RequestBody UserDetails user,

            @PathVariable
            @NotBlank(message = "Token cannot be empty")
            String token) {

        return service.setUserAuthToken(user, token);
    }

    @GetMapping("/{id}")
    public UserDetails getUserDetails(
            @PathVariable
            @Positive(message = "User id must be positive")
            Long id) {

        return service.getUserDetails(id);
    }

    @PutMapping("/menu/{id}/decrease-stock")
    public ResponseEntity<MenuItem> decreaseStock(
            @PathVariable
            @Positive(message = "Menu item id must be positive")
            Long id,

            @RequestParam
            @Positive(message = "Quantity must be greater than 0")
            int qty) {

        return ResponseEntity.ok(
                service.decreaseStock(id, qty)
        );
    }
}