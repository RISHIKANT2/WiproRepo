package com.pizzeria.admin_service.dto;

import com.pizzeria.admin_service.entity.Category;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class MenuItemDto {

	@NotBlank(message = "Item name is required")
	private String itemName;

	@NotNull(message = "Category is required")
	private Category category;

	@Positive(message = "Price must be greater than zero")
	private Double price;

	@NotBlank(message = "Description is required")
	private String description;

	@NotNull(message = "Availability is required")
	private Boolean available;

	@PositiveOrZero(message = "Stock cannot be negative")
	private Integer stock;

	@NotBlank(message = "Image URL is required")
	private String image_src;
	
	public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(
            String description) {
        this.description = description;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(
            Boolean available) {
        this.available = available;
    }

    public String getImage_src() {
        return image_src;
    }

    public void setImage_src(
            String image_src) {
        this.image_src = image_src;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }
}

