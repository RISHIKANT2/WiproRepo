package com.pizzeria.admin_service.dto;

import lombok.Data;

@Data
public class OrderResponseDto {

	private Long id;

    private Long userId;

    private String status;
}
