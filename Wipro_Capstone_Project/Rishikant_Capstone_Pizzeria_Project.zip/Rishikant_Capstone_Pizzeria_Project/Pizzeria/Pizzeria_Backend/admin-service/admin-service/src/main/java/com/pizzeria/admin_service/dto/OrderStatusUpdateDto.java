package com.pizzeria.admin_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderStatusUpdateDto {

	@NotNull(message = "Order id is required")
	private Long orderId;

	@NotBlank(message = "Order status is required")
	private String status;
	
	public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(
            Long orderId) {
        this.orderId = orderId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(
            String status) {
        this.status = status;
    }
}
