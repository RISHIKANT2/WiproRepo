package com.pizzeria.admin_service.entity;

public enum Category {

	  PIZZA,
	    SIDES,
	    BEVERAGES,
	    COMBO,
	    NEW_LAUNCHES,
	    BESTSELLERS
}
