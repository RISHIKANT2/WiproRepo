package com.pizzeria.admin_service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "menu_items")
public class MenuItem {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@NotBlank(message = "Item name is required")
    private String itemName;
   
	@NotNull(message = "Category is required")
    @Enumerated(EnumType.STRING)
    private Category category;

	@Positive(message = "Price must be greater than 0")
    private Double price;

	@NotBlank(message = "Description is required")
    private String description;

	
    private Boolean available;
    
	@NotBlank(message = "Image URL is required")
    private String image_src;
    
    private Integer stock;
}
