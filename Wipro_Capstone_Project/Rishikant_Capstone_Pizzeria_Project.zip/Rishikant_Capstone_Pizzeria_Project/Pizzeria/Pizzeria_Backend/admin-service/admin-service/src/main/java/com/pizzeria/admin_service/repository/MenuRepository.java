package com.pizzeria.admin_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzeria.admin_service.entity.Category;
import com.pizzeria.admin_service.entity.MenuItem;

public interface MenuRepository extends JpaRepository<MenuItem, Long>{

	List<MenuItem> findByCategory(Category category);

	List<MenuItem> findByItemNameContainingIgnoreCase(
	        String itemName);
}
