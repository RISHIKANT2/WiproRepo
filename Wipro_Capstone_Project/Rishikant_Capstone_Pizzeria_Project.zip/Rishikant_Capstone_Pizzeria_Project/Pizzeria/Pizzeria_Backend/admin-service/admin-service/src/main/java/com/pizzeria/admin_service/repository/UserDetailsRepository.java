package com.pizzeria.admin_service.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzeria.admin_service.entity.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, Long>{
	
	Optional<UserDetails> findByEmail( String email);

}
