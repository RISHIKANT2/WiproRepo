package com.pizzeria.admin_service.service;

import java.util.List;

import com.pizzeria.admin_service.dto.AdminLoginDto;
import com.pizzeria.admin_service.dto.MenuItemDto;
import com.pizzeria.admin_service.entity.Category;
import com.pizzeria.admin_service.entity.MenuItem;
import com.pizzeria.admin_service.entity.UserDetails;

public interface AdminService {

	 String adminLogin(AdminLoginDto dto);

	    String addMenuItem(MenuItemDto dto);

	    List<MenuItem> getAllMenuItems();
	    
	    MenuItem updateMenuItem(
	            Long id,
	            MenuItem menuItem);

	    String deleteMenuItem(Long id);
	    
	    List<MenuItem> searchByCategory(
	            Category category);

	    List<MenuItem> searchByName(
	            String name);
	    
	    String acceptOrder(Long orderId);

	    String rejectOrder(Long orderId);
	    
	    String setUserAuthToken(UserDetails user,String token);
	    
	    UserDetails getUserDetails(Long id);
	    
	    MenuItem decreaseStock(Long id, int qty);
}
