package com.pizzeria.admin_service.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.pizzeria.admin_service.dto.AdminLoginDto;
import com.pizzeria.admin_service.dto.MenuItemDto;
import com.pizzeria.admin_service.dto.NotificationRequestDto;
import com.pizzeria.admin_service.dto.OrderResponseDto;
import com.pizzeria.admin_service.dto.UserResponseDto;
import com.pizzeria.admin_service.entity.Admin;
import com.pizzeria.admin_service.entity.Category;
import com.pizzeria.admin_service.entity.MenuItem;
import com.pizzeria.admin_service.entity.UserDetails;
import com.pizzeria.admin_service.exception.ResourceNotFoundException;
import com.pizzeria.admin_service.repository.AdminRepository;
import com.pizzeria.admin_service.repository.MenuRepository;
import com.pizzeria.admin_service.repository.UserDetailsRepository;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminRepository adminRepo;
	
	@Autowired
	MenuRepository menuRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	UserDetailsRepository userRepo;
	
//	@Autowired
//	private JwtUtil jwtUtil;
	
	@Override
	public String adminLogin(AdminLoginDto dto) {
		 Admin admin =
	                adminRepo.findByEmail(dto.getEmail())
	                .orElseThrow(() ->
	                        new RuntimeException(
	                                "Admin Not Found"));

	        if (!admin.getPassword()
	                .equals(dto.getPassword())) {

	            throw new RuntimeException(
	                    "Invalid Password");
	        }
	        
//	        String token =
//	                jwtUtil.generateToken(
//	                        admin.getEmail());

	        return "Login Successfully";
	}

	@Override
	public String addMenuItem(MenuItemDto dto) {
		MenuItem item = new MenuItem();

        item.setItemName(dto.getItemName());
        item.setCategory(dto.getCategory());
        item.setPrice(dto.getPrice());
        item.setDescription(dto.getDescription());
        item.setImage_src(dto.getImage_src());
        item.setAvailable(dto.getAvailable());
        item.setStock(dto.getStock());

        menuRepo.save(item);

        return "Menu Item Added";
	}

	@Override
	public List<MenuItem> getAllMenuItems() {
		return menuRepo.findAll();
	}

	@Override
	public MenuItem updateMenuItem(
	        Long id,
	        MenuItem updatedItem) {

	    MenuItem existing = menuRepo.findById(id)
	                         .orElseThrow(() -> new ResourceNotFoundException(
	                                 "Menu item not found with id: " + id
	                                 ));

	    existing.setItemName(
	            updatedItem.getItemName());
	    existing.setDescription(updatedItem.getDescription());
	    existing.setImage_src(updatedItem.getImage_src());

	    existing.setCategory(
	            updatedItem.getCategory());

	    existing.setPrice(
	            updatedItem.getPrice());

	    return menuRepo.save(existing);
	}
	
	@Override
	public String deleteMenuItem(Long id) {
		 menuRepo.deleteById(id);

	        return "Deleted Successfully";
	    
	}
	
	@Override
	public List<MenuItem> searchByCategory(
	        Category category) {

	    return menuRepo.findByCategory(category);
	}

	@Override
	public List<MenuItem> searchByName(
	        String name) {

	    return menuRepo
	            .findByItemNameContainingIgnoreCase(
	                    name);
	}
	
	public String acceptOrder(Long orderId) {

		 String url =
		            "http://order-service/orders/status/"
		                    + orderId
		                    + "/ACCEPTED";

		    restTemplate.put(url, null);
		    
		    OrderResponseDto order =
		            restTemplate.getForObject(

		                    "http://order-service/orders/"
		                            + orderId,

		                    OrderResponseDto.class);

		    if(order == null) {

		        throw new RuntimeException(
		                "Order not found");
		    }
		    Optional<UserDetails> user1 = userRepo.findById(order.getUserId());

		    if(user1.isEmpty()) {
		        throw new RuntimeException("User not found");
		    }

		    String token = user1.get().getAuthToken();
		    System.out.println(token);

		    HttpHeaders headers = new HttpHeaders();
		    headers.setBearerAuth(token);

		    HttpEntity<String> entity = new HttpEntity<>(headers);

		    
		    
		    
		    ResponseEntity<UserResponseDto> response =
		            restTemplate.exchange(
		                    "http://user-service/users/" + order.getUserId(),
		                    HttpMethod.GET,
		                    entity,
		                    UserResponseDto.class);

		    UserResponseDto user = response.getBody();
		    
		    

		    if(user == null) {

		        throw new RuntimeException(
		                "User not found");
		    }
		    
		    System.out.println(user.getEmail());
		    
		    NotificationRequestDto notification =
		            new NotificationRequestDto();

		    notification.setEmail(
		            user.getEmail());

		    notification.setSubject(
		            "Order Accepted");

		    notification.setMessage(

		            "Hello " +

		            user.getName() +

		            ", your order #" +

		            orderId +

		            " has been accepted."
		    );
		    
		    restTemplate.postForObject(

		            "http://notification-service/notifications/send",

		            notification,

		            String.class
		    );

		    return "Order Accepted Successfully";
		}

	@Override
	public String rejectOrder(Long orderId) {
		String url =
	            "http://order-service/orders/status/"
	                    + orderId
	                    + "/REJECTED";

	    restTemplate.put(url, null);
	    
	    OrderResponseDto order =
	            restTemplate.getForObject(

	                    "http://order-service/orders/"
	                            + orderId,

	                    OrderResponseDto.class);

	    if(order == null) {

	        throw new RuntimeException("Order not found");
	    }
	    
	    Optional<UserDetails> user1 = userRepo.findById(order.getUserId());

	    if(user1.isEmpty()) {
	        throw new RuntimeException("User not found");
	    }

	    String token = user1.get().getAuthToken();

	    HttpHeaders headers = new HttpHeaders();
	    headers.setBearerAuth(token);

	    HttpEntity<String> entity = new HttpEntity<>(headers);

	    ResponseEntity<UserResponseDto> response =
	            restTemplate.exchange(
	                    "http://user-service/users/" + order.getUserId(),
	                    HttpMethod.GET,
	                    entity,
	                    UserResponseDto.class);

	    UserResponseDto user = response.getBody();

	    if(user == null) {

	        throw new RuntimeException(
	                "User not found");
	    }

	    NotificationRequestDto notification =
	            new NotificationRequestDto();

	    notification.setEmail(
	            user.getEmail());

	    notification.setSubject(
	            "Order Rejected");

	    notification.setMessage(

	            "Hello " +

	            user.getName() +

	            ", your order #" +

	            orderId +

	            " has been rejected."
	    );

	    restTemplate.postForObject(

	            "http://notification-service/notifications/send",

	            notification,

	            String.class
	    );

	    return "Order Rejected Successfully";
	}
	
	public String setUserAuthToken(UserDetails user,String token) {
		UserDetails user1 = new UserDetails();
		

		user1.setId(user.getId()); // important
		user1.setAuthToken(token);
		user1.setEmail(user.getEmail());
		user1.setName(user.getName());

		userRepo.save(user1);
		
		
		return "AuthoToken saved Successfully";
	}
   
	public UserDetails getUserDetails(Long id) {
		return userRepo.findById(id).get();
	}
	
	@Override
	public MenuItem decreaseStock(Long id, int qty) {

	    MenuItem item = menuRepo.findById(id)
	            .orElseThrow(() -> new RuntimeException("Item not found"));

	    if (item.getStock() < qty) {
	        throw new RuntimeException("Not enough stock");
	    }

	    item.setStock(item.getStock() - qty);

	    return menuRepo.save(item);
	}

}
