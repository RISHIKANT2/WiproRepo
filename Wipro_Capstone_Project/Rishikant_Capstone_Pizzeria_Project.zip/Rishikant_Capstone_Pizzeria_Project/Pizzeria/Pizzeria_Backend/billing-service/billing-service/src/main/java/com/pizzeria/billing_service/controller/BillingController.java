package com.pizzeria.billing_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.pizzeria.billing_service.dto.BillResponseDto;
import com.pizzeria.billing_service.service.BillingService;

import jakarta.validation.constraints.Positive;

@RestController
@RequestMapping("/billing")
public class BillingController {
	
	@Autowired
	BillingService service;

	 @GetMapping("/generate/{orderId}")
	    public BillResponseDto generate(@PathVariable
	    		@Positive(message = "Order id must be positive")
	    		Long orderId) {
	        return service.generateBill(orderId);
	    }
}
