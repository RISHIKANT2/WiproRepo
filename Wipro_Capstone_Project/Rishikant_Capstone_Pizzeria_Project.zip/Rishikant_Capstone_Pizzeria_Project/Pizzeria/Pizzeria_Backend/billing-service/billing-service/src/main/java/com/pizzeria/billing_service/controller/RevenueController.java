package com.pizzeria.billing_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pizzeria.billing_service.dto.RevenueResponse;
import com.pizzeria.billing_service.service.RevenueService;

@RestController
public class RevenueController {

	 @Autowired
	    private RevenueService revenueService;

	 @GetMapping("/billing/revenue/history")
	 public List<RevenueResponse> getRevenueHistory() {
	     return revenueService.getRevenueHistory();
	 }
}
