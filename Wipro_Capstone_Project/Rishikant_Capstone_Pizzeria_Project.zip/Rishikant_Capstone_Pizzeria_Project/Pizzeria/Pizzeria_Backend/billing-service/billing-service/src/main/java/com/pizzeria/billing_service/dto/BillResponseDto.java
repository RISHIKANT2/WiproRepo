package com.pizzeria.billing_service.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class BillResponseDto {

	@NotNull(message = "Order id is required")
	private Long orderId;

	@PositiveOrZero(message = "Subtotal cannot be negative")
	private Double subtotal;

	@PositiveOrZero(message = "GST cannot be negative")
	private Double gst;

	@PositiveOrZero(message = "Delivery charge cannot be negative")
	private Double deliveryCharge;

	@PositiveOrZero(message = "Total amount cannot be negative")
	private Double totalAmount;
}
