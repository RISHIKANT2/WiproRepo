package com.pizzeria.billing_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class OrderItemDto {

	 @NotBlank(message = "Item name is required")
	private String itemName;
	 
	 @Positive(message = "Quantity must be greater than 0")
    private Integer quantity;
	 
	 @PositiveOrZero(message = "Price cannot be negative")
    private Double price;
}
