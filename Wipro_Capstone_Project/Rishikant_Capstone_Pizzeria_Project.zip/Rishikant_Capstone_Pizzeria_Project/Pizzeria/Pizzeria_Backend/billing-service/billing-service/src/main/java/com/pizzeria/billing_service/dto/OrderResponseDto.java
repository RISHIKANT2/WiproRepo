package com.pizzeria.billing_service.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderResponseDto {

	
	private Long id;
	
	@NotNull(message = "User id is required")
    private Long userId;
	
	@NotEmpty(message = "Order must contain at least one item")
	@Valid
    private List<OrderItemDto> items;

}
