package com.pizzeria.billing_service.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class RevenueResponse {

	private LocalDate date;
	@PositiveOrZero(message = "Revenue cannot be negative")
    private Double revenue;

    public RevenueResponse(LocalDate date, Double revenue) {
        this.date = date;
        this.revenue = revenue;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Double getRevenue() {
        return revenue;
    }

    public void setRevenue(Double revenue) {
        this.revenue = revenue;
    }
}

   


