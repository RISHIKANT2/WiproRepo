package com.pizzeria.billing_service.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.pizzeria.billing_service.entity.Bill;

public interface BillRepository extends JpaRepository<Bill, Long>{

	
	@Query("""
	           SELECT SUM(b.totalAmount)
	           FROM Bill b
	           WHERE b.generatedAt BETWEEN :startDate AND :endDate
	           """)
	    Double getRevenueBetweenDates(
	            LocalDateTime startDate,
	            LocalDateTime endDate);

	    Bill findFirstByOrderByGeneratedAtAsc();

}
