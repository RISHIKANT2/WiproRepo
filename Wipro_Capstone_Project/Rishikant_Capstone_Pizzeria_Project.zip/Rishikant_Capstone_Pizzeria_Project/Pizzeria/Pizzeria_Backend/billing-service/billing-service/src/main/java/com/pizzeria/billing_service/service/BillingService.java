package com.pizzeria.billing_service.service;

import com.pizzeria.billing_service.dto.BillResponseDto;

public interface BillingService {

	BillResponseDto generateBill(Long orderId);
}
