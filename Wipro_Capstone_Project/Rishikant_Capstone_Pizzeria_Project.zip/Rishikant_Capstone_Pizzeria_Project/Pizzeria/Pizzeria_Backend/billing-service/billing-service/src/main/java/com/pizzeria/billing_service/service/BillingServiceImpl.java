package com.pizzeria.billing_service.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pizzeria.billing_service.dto.BillResponseDto;
import com.pizzeria.billing_service.dto.OrderResponseDto;
import com.pizzeria.billing_service.entity.Bill;
import com.pizzeria.billing_service.exception.OrderNotFoundException;
import com.pizzeria.billing_service.repository.BillRepository;

@Service
public class BillingServiceImpl implements BillingService{
	
	
	@Autowired
	BillRepository repo;
	
	@Autowired 
	RestTemplate restTemplate;

	@Override
	public BillResponseDto generateBill(Long orderId) {
		String url =
		        "http://order-service/orders/" + orderId;

		        OrderResponseDto order =
		        restTemplate.getForObject(url,
		                OrderResponseDto.class);

		        if(order == null) {
		        	throw new OrderNotFoundException("Order not found with id: " + orderId);
		        }

		        double subtotal =
		        order.getItems().stream()
		                .mapToDouble(i ->
		                    i.getPrice() * i.getQuantity())
		                .sum();

		        double gst = subtotal * 0.05; // 5% GST

		        double delivery = 40.0;

		        double total = subtotal + gst + delivery;
		        LocalDateTime currentDateTime = LocalDateTime.now();

		        Bill bill = new Bill();

		        bill.setOrderId(orderId);
		        bill.setSubtotal(subtotal);
		        bill.setGst(gst);
		        bill.setDeliveryCharge(delivery);
		        bill.setTotalAmount(total);
		        bill.setGeneratedAt(currentDateTime);

		        repo.save(bill);

		        BillResponseDto dto = new BillResponseDto();
		        dto.setOrderId(orderId);
		        dto.setSubtotal(subtotal);
		        dto.setGst(gst);
		        dto.setDeliveryCharge(delivery);
		        dto.setTotalAmount(total);

		        return dto;
	}

}
