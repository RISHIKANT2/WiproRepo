package com.pizzeria.billing_service.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizzeria.billing_service.dto.RevenueResponse;
import com.pizzeria.billing_service.entity.Bill;
import com.pizzeria.billing_service.repository.BillRepository;

@Service
public class RevenueService {

	@Autowired
    private BillRepository billRepository;

	public List<RevenueResponse> getRevenueHistory() {

        List<RevenueResponse> revenueList = new ArrayList<>();

        Bill firstBill = billRepository.findFirstByOrderByGeneratedAtAsc();

        if (firstBill == null) {
            return revenueList;
        }

        LocalDate startDate =
                firstBill.getGeneratedAt().toLocalDate();

        LocalDate today = LocalDate.now();

        while (!startDate.isAfter(today)) {

            LocalDateTime start =
                    startDate.atStartOfDay();

            LocalDateTime end =
                    startDate.atTime(23, 59, 59);

            Double revenue =
                    billRepository.getRevenueBetweenDates(
                            start,
                            end);

            revenueList.add(
                    new RevenueResponse(
                            startDate,
                            revenue == null ? 0.0 : revenue
                    )
            );

            startDate = startDate.plusDays(1);
        }

        return revenueList;
    }
}
