package com.pizzeria.dicovery_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class DicoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DicoveryServerApplication.class, args);
	}

}
