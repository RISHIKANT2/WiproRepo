package com.pizzeria.notification_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.pizzeria.notification_service.dto.NotificationRequestDto;
import com.pizzeria.notification_service.service.NotificationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

	
	@Autowired
	NotificationService service;
	

    @PostMapping("/send")
    public String sendNotification(
    		@Valid
            @RequestBody NotificationRequestDto dto) {

        return service.sendNotification(dto);
    }
}
