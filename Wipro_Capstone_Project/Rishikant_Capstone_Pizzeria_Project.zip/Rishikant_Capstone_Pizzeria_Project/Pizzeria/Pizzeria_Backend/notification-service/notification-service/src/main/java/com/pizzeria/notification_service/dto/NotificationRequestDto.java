package com.pizzeria.notification_service.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class NotificationRequestDto {

	
	@Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
	private String email;

	@NotBlank(message = "Notification subject is required")
    private String subject;

    @NotBlank(message = "Notification message is required")
    private String message;
    
    public String getEmail() {
        return email;
    }

    public void setEmail(
            String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(
            String message) {
        this.message = message;
    }
    
    public String getSubject() {
        return subject;
    }

    public void setSubject(
            String subject) {
        this.subject = subject;
    }
    
}
