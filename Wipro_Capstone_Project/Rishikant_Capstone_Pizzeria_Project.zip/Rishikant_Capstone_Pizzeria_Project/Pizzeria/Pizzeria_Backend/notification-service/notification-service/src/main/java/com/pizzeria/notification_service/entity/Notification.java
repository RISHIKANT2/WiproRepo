package com.pizzeria.notification_service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Notification {

	
	@Id
    @GeneratedValue(strategy =
            GenerationType.IDENTITY)
    private Long id;
    
	@Email(message = "Invalid email format")
	@NotBlank(message = "Email is required")
    private String email;

	@NotBlank(message = "Subject cannot be empty")
    private String subject;

	@NotBlank(message = "Message cannot be empty")
    private String message;

    private LocalDateTime sentAt;
}
