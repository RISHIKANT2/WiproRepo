package com.pizzeria.notification_service.exception;

public class NotificationSendFailedException extends RuntimeException {

    public NotificationSendFailedException(String message) {
        super(message);
    }
}
