package com.pizzeria.notification_service.service;

import com.pizzeria.notification_service.dto.NotificationRequestDto;

public interface NotificationService {

	String sendNotification(
            NotificationRequestDto dto);
}
