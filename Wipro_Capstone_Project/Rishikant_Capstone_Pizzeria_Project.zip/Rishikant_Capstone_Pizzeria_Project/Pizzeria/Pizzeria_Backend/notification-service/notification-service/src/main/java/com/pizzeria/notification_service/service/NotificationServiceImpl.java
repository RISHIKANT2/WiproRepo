package com.pizzeria.notification_service.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.pizzeria.notification_service.dto.NotificationRequestDto;
import com.pizzeria.notification_service.entity.Notification;
import com.pizzeria.notification_service.repository.NotificationRepository;

@Service
public class NotificationServiceImpl implements NotificationService{
	
	
	@Autowired
	NotificationRepository repository;
	
	@Autowired
	JavaMailSender mailSender;

	@Override
	public String sendNotification(NotificationRequestDto dto) {
		
		Notification notification = new Notification();
		
		notification.setEmail(dto.getEmail());
        notification.setSubject(dto.getSubject());
        notification.setMessage(dto.getMessage());
        notification.setSentAt(
                LocalDateTime.now());

        repository.save(notification);
        SimpleMailMessage mail =
                new SimpleMailMessage();

        mail.setTo(dto.getEmail());

        mail.setSubject(dto.getSubject());

        mail.setText(dto.getMessage());

        mailSender.send(mail);

        return "Notification Sent Successfully";
	}

}
