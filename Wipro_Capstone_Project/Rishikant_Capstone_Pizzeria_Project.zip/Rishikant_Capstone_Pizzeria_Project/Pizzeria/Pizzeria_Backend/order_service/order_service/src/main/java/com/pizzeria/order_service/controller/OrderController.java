package com.pizzeria.order_service.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.pizzeria.order_service.dto.OrderRequestDto;
import com.pizzeria.order_service.entity.Order;
import com.pizzeria.order_service.service.OrderService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;

@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	OrderService service;
	
	@PostMapping("/place")
    public Order placeOrder(
    		@Valid
            @RequestBody OrderRequestDto dto) {

        return service.placeOrder(dto);
    }

    @PutMapping("/cancel/{id}")
    public String cancelOrder(
    		@Positive(message = "Order id must be positive")
            @PathVariable Long id) {

        return service.cancelOrder(id);
    }

    @GetMapping
    public List<Order> getAllOrders() {

        return service.getAllOrders();
    }
    
    @GetMapping("/{id}")
    public Optional<Order> getOrderById(@PathVariable
    		@Positive(message = "Order id must be positive")
    		Long id) {

        return service.getOrderById(id);
    }
    
    @PutMapping("/status/{orderId}/{status}")
    public String updateStatus(
    		@Positive(message = "Order id must be positive")
            @PathVariable Long orderId,
            @PathVariable String status) {

        return service.updateStatus(
                orderId,
                status);
    }
}
