package com.pizzeria.order_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class MenuItemResponseDto {

	private Long id;

    @NotBlank(message = "Item name is required")
    private String itemName;

    @PositiveOrZero(message = "Price cannot be negative")
    private Double price;

    @NotBlank(message = "Item description is required")
    private String description;
    
    
    @NotBlank(message = "Item categoryis required")
    private String category;
}
