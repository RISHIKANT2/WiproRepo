package com.pizzeria.order_service.dto;

import java.util.List;

import com.pizzeria.order_service.entity.DeliveryMode;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderRequestDto {

	private Long userId;

	@NotNull(message = "Delivery mode is required")
    private DeliveryMode deliveryMode;

	@NotEmpty(message = "Order must contain at least one item")
    @Valid
    private List<PlaceOrderItemDto> items;
	
	 public Long getUserId() {
	        return userId;
	    }

	    public void setUserId(
	            Long userId) {
	        this.userId = userId;
	    }

	    public DeliveryMode getDeliveryMode() {
	        return deliveryMode;
	    }

	    public void setDeliveryMode(
	            DeliveryMode deliveryMode) {
	        this.deliveryMode = deliveryMode;
	    }

	    public List<PlaceOrderItemDto> getItems() {
	        return items;
	    }

	    public void setItems(
	            List<PlaceOrderItemDto> items) {
	        this.items = items;
	    }
	
}
