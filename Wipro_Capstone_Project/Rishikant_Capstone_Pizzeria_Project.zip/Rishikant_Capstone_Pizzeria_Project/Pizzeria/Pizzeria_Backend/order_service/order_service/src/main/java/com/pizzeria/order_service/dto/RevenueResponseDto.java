package com.pizzeria.order_service.dto;

public class RevenueResponseDto {

}
