package com.pizzeria.order_service.entity;

public enum DeliveryMode {

	
	HOME_DELIVERY,

    TAKE_AWAY
}
