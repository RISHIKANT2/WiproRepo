package com.pizzeria.order_service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderItem {
	 @Id
	    @GeneratedValue(strategy =GenerationType.IDENTITY)
	    private Long id;

	    private Long menuItemId;

	    private String itemName;

	    private Integer quantity;

	    private Double price;

}
