package com.pizzeria.order_service.entity;

public enum OrderStatus {

	PENDING,

    ACCEPTED,

    REJECTED,

    PREPARING,

    OUT_FOR_DELIVERY,

    DELIVERED,

    CANCELLED
}
