package com.pizzeria.order_service.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.pizzeria.order_service.dto.MenuItemResponseDto;

@FeignClient(name = "ADMIN-SERVICE")
public interface MenuFeignClient {

	@GetMapping("/admin/menu")
    List<MenuItemResponseDto> getAllMenu();
}
