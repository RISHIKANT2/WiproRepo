package com.pizzeria.order_service.service;

import java.util.List;
import java.util.Optional;

import com.pizzeria.order_service.dto.OrderRequestDto;
import com.pizzeria.order_service.entity.Order;

public interface OrderService {

	Order placeOrder(OrderRequestDto dto);

    String cancelOrder(Long orderId);

    List<Order> getAllOrders();
    
    Optional<Order> getOrderById(Long id);
    
    String updateStatus(
            Long orderId,
            String status);
}
