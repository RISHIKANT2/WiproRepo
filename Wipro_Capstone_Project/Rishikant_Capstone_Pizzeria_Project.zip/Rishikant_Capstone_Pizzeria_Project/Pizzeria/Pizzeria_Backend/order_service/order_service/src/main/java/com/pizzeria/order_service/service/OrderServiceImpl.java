package com.pizzeria.order_service.service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pizzeria.order_service.dto.MenuItemResponseDto;
import com.pizzeria.order_service.dto.OrderRequestDto;
import com.pizzeria.order_service.entity.Order;
import com.pizzeria.order_service.entity.OrderItem;
import com.pizzeria.order_service.entity.OrderStatus;
import com.pizzeria.order_service.exception.MenuItemNotFoundException;
import com.pizzeria.order_service.exception.OrderNotFoundException;
import com.pizzeria.order_service.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository  orderRepo;
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public Order placeOrder(OrderRequestDto dto) {
		 Order order = new Order();
		 
		 String url = "http://ADMIN-SERVICE/admin/menu";

		 ResponseEntity<MenuItemResponseDto[]> response =
		         restTemplate.getForEntity(url, MenuItemResponseDto[].class);

		 MenuItemResponseDto[] menuItems = response.getBody();
		 if (menuItems == null) {
			 throw new MenuItemNotFoundException(
		                "Menu item not found with id: "
		                        
		        );
			}

	        order.setUserId(dto.getUserId());

	        order.setDeliveryMode(
	                dto.getDeliveryMode());

	        order.setStatus(
	                OrderStatus.PENDING);

	        order.setOrderDate(
	                LocalDateTime.now());

	        List<OrderItem> items =
	                dto.getItems().stream().map(reqItem -> {

	            MenuItemResponseDto menuItem =
	                    Arrays.stream(menuItems)
	                            .filter(m -> m.getId().equals(reqItem.getMenuItemId()))
	                            .findFirst()
	                            .orElseThrow(() ->
	                             new MenuItemNotFoundException(
	            		                "Menu item not found with id: "
	            		                        
	            		        ));

	            OrderItem item = new OrderItem();

	            item.setMenuItemId(menuItem.getId());
	            item.setItemName(menuItem.getItemName());
	            item.setQuantity(reqItem.getQuantity());
	            item.setPrice(menuItem.getPrice()); // 🔥 FIXED PRICE

	            return item;

	        }).toList();
	        order.setItems(items);

	        double total =
	                items.stream()
	                        .mapToDouble(i ->
	                                i.getPrice() *
	                                i.getQuantity())
	                        .sum();

	        order.setTotalAmount(total);

	        return orderRepo.save(order);
	}

	@Override
	public String cancelOrder(Long orderId) {
		Order order =
                orderRepo.findById(orderId)
                        .orElseThrow();

        order.setStatus(
                OrderStatus.CANCELLED);

        orderRepo.save(order);

        return "Order Cancelled";
	}

	@Override
	public List<Order> getAllOrders() {
		 return orderRepo.findAll();
	}

	@Override
	public Optional<Order> getOrderById(Long id) {
		return orderRepo.findById(id);
	}
	
	@Override
	public String updateStatus(
	        Long orderId,
	        String status) {

	    Order order = orderRepo.findById(orderId)
	            .orElseThrow(() ->
	                    new OrderNotFoundException(
	                            "Order not found"));

	    order.setStatus(
	            OrderStatus.valueOf(status));

	    orderRepo.save(order);

	    return "Status Updated";
	}
	
	

}
