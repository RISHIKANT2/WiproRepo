package com.pizzeria.payment_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.pizzeria.payment_service.dto.PaymentRequestDto;
import com.pizzeria.payment_service.dto.PaymentResponseDto;
import com.pizzeria.payment_service.dto.UserDto;
import com.pizzeria.payment_service.service.PaymentService;

@RestController
@RequestMapping("/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    PaymentService service;
    
    @Autowired
    RestTemplate restTemplate;

	@PostMapping("/pay")
    public PaymentResponseDto pay(@RequestBody PaymentRequestDto dto) {
        return service.makePayment(dto);
    }
	
	@GetMapping("/user/{id}")
	public UserDto getUserDetails(
	        @PathVariable Long id) {

	    return service.getUserDetails(id);
	}
}
