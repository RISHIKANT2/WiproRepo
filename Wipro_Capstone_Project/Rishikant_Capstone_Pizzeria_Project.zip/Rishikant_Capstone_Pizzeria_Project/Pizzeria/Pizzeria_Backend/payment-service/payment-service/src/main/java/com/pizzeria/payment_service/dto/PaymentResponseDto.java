package com.pizzeria.payment_service.dto;

import com.pizzeria.payment_service.entity.PaymentMode;

import lombok.Data;

@Data
public class PaymentResponseDto {

	 private Long orderId;
	    private Double amount;
	    private PaymentMode paymentMode;
	    private String status;
}
