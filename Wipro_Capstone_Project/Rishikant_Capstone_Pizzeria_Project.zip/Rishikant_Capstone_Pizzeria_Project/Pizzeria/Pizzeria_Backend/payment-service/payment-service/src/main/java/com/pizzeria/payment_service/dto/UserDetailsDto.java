package com.pizzeria.payment_service.dto;

import jakarta.persistence.Id;
import lombok.Data;

@Data
public class UserDetailsDto {

	
	Long id;
	
	String name;
	
	String email;
	
	String authToken;
}
