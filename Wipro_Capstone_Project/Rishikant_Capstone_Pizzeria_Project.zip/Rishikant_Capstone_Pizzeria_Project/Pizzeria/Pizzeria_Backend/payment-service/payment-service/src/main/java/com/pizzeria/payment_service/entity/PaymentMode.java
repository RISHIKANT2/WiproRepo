package com.pizzeria.payment_service.entity;

public enum PaymentMode {

	UPI,
    CARD,
    CASH_ON_DELIVERY
}
