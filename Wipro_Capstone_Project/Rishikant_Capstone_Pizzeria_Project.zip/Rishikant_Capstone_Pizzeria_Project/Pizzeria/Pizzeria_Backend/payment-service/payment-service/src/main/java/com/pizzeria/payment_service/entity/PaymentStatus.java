package com.pizzeria.payment_service.entity;

public enum PaymentStatus {
 
	 PENDING,
	    SUCCESS,
	    FAILED
}
