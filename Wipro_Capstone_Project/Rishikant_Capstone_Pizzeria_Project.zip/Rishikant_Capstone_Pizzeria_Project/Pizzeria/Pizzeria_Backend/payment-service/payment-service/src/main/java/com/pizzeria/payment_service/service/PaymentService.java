package com.pizzeria.payment_service.service;

import com.pizzeria.payment_service.dto.PaymentRequestDto;
import com.pizzeria.payment_service.dto.PaymentResponseDto;
import com.pizzeria.payment_service.dto.UserDto;

public interface PaymentService{

	PaymentResponseDto makePayment(PaymentRequestDto dto);
	
	UserDto getUserDetails(Long id);
}
