package com.pizzeria.payment_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;


import com.pizzeria.payment_service.dto.PaymentRequestDto;
import com.pizzeria.payment_service.dto.PaymentResponseDto;
import com.pizzeria.payment_service.dto.UserDetailsDto;
import com.pizzeria.payment_service.dto.UserDto;
import com.pizzeria.payment_service.entity.Payment;
import com.pizzeria.payment_service.entity.PaymentMode;
import com.pizzeria.payment_service.entity.PaymentStatus;
import com.pizzeria.payment_service.repository.PaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService{
	
	@Autowired
	PaymentRepository repo;
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public PaymentResponseDto makePayment(PaymentRequestDto dto) {
		
	        Payment payment = new Payment();

	        payment.setOrderId(dto.getOrderId());
	        payment.setAmount(dto.getAmount());
	        payment.setPaymentMode(dto.getPaymentMode());

	        // simple simulation logic
	        if (dto.getPaymentMode() == PaymentMode.CASH_ON_DELIVERY) {
	            payment.setStatus(PaymentStatus.PENDING);
	        } else {
	            payment.setStatus(PaymentStatus.SUCCESS);
	        }

	        repo.save(payment);

	        PaymentResponseDto response = new PaymentResponseDto();
	        response.setOrderId(dto.getOrderId());
	        response.setAmount(dto.getAmount());
	        response.setPaymentMode(dto.getPaymentMode());
	        response.setStatus(payment.getStatus().toString());

	        return response;

    }
	
	
	public UserDto getUserDetails(
	        @PathVariable Long id) {
		
		UserDetailsDto userDetails =
	            restTemplate.getForObject(

	                    "http://admin-service/admin/"
	                            + id,

	                            UserDetailsDto.class);
		
		String token= userDetails.getAuthToken();

		 HttpHeaders headers = new HttpHeaders();
		    headers.setBearerAuth(token);

		    HttpEntity<String> entity = new HttpEntity<>(headers);

		    ResponseEntity<UserDto> response =
		            restTemplate.exchange(
		                    "http://user-service/users/" + id,
		                    HttpMethod.GET,
		                    entity,
		                    UserDto.class);

		    UserDto user = response.getBody();
		    
		    return user;
	}
}
