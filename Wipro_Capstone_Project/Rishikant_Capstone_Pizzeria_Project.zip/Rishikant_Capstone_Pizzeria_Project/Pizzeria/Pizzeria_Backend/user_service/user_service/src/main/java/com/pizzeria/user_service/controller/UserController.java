package com.pizzeria.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizzeria.user_service.dto.LoginRequestDto;
import com.pizzeria.user_service.dto.LoginResponseDto;
import com.pizzeria.user_service.dto.UserRegisterDto;
import com.pizzeria.user_service.entity.User;
import com.pizzeria.user_service.service.UserService;

@RestController
@RequestMapping("/users")
//@CrossOrigin(origins = "http://127.0.0.1:5500")
public class UserController {

	
	@Autowired
	UserService service;
	
	@PostMapping("/register")
	public String register(
            @RequestBody UserRegisterDto dto) {

        return service.register(dto);
    }

	 @PostMapping("/login")
	    public LoginResponseDto login(
	            @RequestBody LoginRequestDto dto) {

	        return service.login(dto);
	    }
	 
	 @GetMapping("/{userId}")
	 public User getUserById(
	         @PathVariable Long userId) {

	     return service.getUserById(userId);
	 }
	 @PostMapping("/address/{userId}")
	 public String updateUserById(
	         @PathVariable Long userId,
	         @RequestBody String address) {

	     return service.updateUserById(userId,address);
	 }
}
