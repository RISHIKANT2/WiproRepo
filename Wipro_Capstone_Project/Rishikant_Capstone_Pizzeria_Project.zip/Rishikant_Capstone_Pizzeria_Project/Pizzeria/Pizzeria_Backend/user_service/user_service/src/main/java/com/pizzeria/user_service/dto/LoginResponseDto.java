package com.pizzeria.user_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponseDto {

	private String message;
	private String token;
	private Long userId;
}
