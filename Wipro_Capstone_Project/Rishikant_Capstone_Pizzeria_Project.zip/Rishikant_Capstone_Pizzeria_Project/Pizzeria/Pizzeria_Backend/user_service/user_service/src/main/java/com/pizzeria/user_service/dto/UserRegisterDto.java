package com.pizzeria.user_service.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UserRegisterDto {

	 @NotBlank
	    private String name;

	    @Email
	    private String email;

	    @NotBlank
	    private String password;

	    private String phone;

	    private String address;
}
