package com.pizzeria.user_service.entity;

public enum Role {
	ROLE_USER,
    ROLE_ADMIN
}
