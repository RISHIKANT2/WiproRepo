package com.pizzeria.user_service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.swagger.v3.oas.annotations.Hidden;

@Hidden
@RestControllerAdvice
public class GlobalExceptionHandler {

	 @ExceptionHandler(
	            UserAlreadyExistsException.class)
	    public ResponseEntity<String>
	    handleUserExists(
	            UserAlreadyExistsException ex) {

	        return new ResponseEntity<>(
	                ex.getMessage(),
	                HttpStatus.BAD_REQUEST);
	    }
}
