package com.pizzeria.user_service.exception;

public class UserAlreadyExistsException extends RuntimeException{
  public UserAlreadyExistsException(String msg) {
	  super(msg);
  }
}
