package com.pizzeria.user_service.security;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

	 private final String SECRET = "mysecretkeymysecretkeymysecretkey12345";

	    private Key getKey() {
	        return Keys.hmacShaKeyFor(SECRET.getBytes());
	    }

	    // Generate Token
	    public String generateToken(String email) {

	        return Jwts.builder()
	                .setSubject(email)
	                .setIssuedAt(new Date())
	                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour
	                .signWith(getKey(), SignatureAlgorithm.HS256)
	                .compact();
	    }

	    // Extract Email
	    public String extractEmail(String token) {

	        return Jwts.parserBuilder()
	                .setSigningKey(getKey())
	                .build()
	                .parseClaimsJws(token)
	                .getBody()
	                .getSubject();
	    }

	    // Validate Token
	    public boolean validateToken(String token) {
	        try {
	            Jwts.parserBuilder()
	                    .setSigningKey(getKey())
	                    .build()
	                    .parseClaimsJws(token);
	            return true;
	        } catch (Exception e) {
	            return false;
	        }
	    }
}
