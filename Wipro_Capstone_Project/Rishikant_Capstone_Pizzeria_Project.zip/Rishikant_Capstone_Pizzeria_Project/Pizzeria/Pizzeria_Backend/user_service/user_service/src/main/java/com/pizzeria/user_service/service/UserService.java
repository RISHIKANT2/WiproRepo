package com.pizzeria.user_service.service;


import org.springframework.stereotype.Service;
import com.pizzeria.user_service.dto.LoginRequestDto;
import com.pizzeria.user_service.dto.LoginResponseDto;
import com.pizzeria.user_service.dto.UserRegisterDto;
import com.pizzeria.user_service.entity.User;



public interface UserService {
	
	String register(UserRegisterDto dto);

    LoginResponseDto login(LoginRequestDto dto);
    
    User getUserById(Long userId);
    
    String updateUserById(Long id,String address);
}
