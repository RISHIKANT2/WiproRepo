package com.pizzeria.user_service.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pizzeria.user_service.dto.LoginRequestDto;
import com.pizzeria.user_service.dto.LoginResponseDto;
import com.pizzeria.user_service.dto.UserRegisterDto;
import com.pizzeria.user_service.entity.User;
import com.pizzeria.user_service.exception.UserAlreadyExistsException;
import com.pizzeria.user_service.repository.UserRepository;
import com.pizzeria.user_service.security.JwtUtil;
import com.pizzeria.user_service.service.UserService;


@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository repository;
	
	@Autowired
	JwtUtil jwtUtil;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public String register(UserRegisterDto dto) {
		 Optional<User> existing =
	                repository.findByEmail(dto.getEmail());

	        if (existing.isPresent()) {
	            throw new UserAlreadyExistsException(
	                    "Email already registered");
	        }

	        User user = new User();

	        user.setName(dto.getName());
	        user.setEmail(dto.getEmail());
	        user.setPassword(passwordEncoder.encode(dto.getPassword()));
	        user.setPhone(dto.getPhone());
	        user.setAddress(dto.getAddress());
	        user.setRole("USER");

	        repository.save(user);

	        return "User Registered Successfully";
	}

	@Override
	public LoginResponseDto login(LoginRequestDto dto) {
		 User user = repository.findByEmail(
	                dto.getEmail())
	                .orElseThrow(() ->
	                        new RuntimeException(
	                                "Invalid Email"));
		 System.out.println("Received User ID = " + user.getId());
			System.out.println("Received User = " + user);

		 if (!passwordEncoder.matches(
			        dto.getPassword(),
			        user.getPassword())) {


	            throw new RuntimeException("Invalid Password");
	        }
	        
	        String token = jwtUtil.generateToken(user.getEmail());
	        System.out.println(token);
	        HttpEntity<User> request = new HttpEntity<>(user);
	        
	        restTemplate.exchange(
	                "http://admin-service/admin/" + token,
	                HttpMethod.PUT,
	                request,
	                String.class
	        );
	        
	        
	        

	        return new LoginResponseDto(
	                "Login Successful",token,user.getId());
	    
	}
	
	@Override
	public User getUserById(Long userId) {

	    return repository.findById(userId)
	            .orElseThrow(() ->
	                    new RuntimeException(
	                            "User not found"));
	}
	public String updateUserById(Long id, String address) {
		Optional<User> user= repository.findById(id);
		if(!user.isPresent()) {
			throw new RuntimeException(
                    "User Not Found");
		}
	   user.get().setAddress(address);
	   repository.save(user.get());
	   return "User Address Saved Successfully";
	   
	}

}
