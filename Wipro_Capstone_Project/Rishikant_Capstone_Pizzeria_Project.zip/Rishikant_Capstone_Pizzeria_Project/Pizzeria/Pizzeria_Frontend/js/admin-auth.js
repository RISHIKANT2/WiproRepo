async function adminLogin() {

	try {

		const loginData = {

			email:
				document.getElementById("email").value,

			password:
				document.getElementById("password").value
		};

		const response = await fetch(
			"http://localhost:8083/admin/login",
			{
				method: "POST",

				headers: {
					"Content-Type": "application/json"
				},

				body: JSON.stringify(loginData)
			}
		);

		if (response.ok) {

			const token = await response.text();

			localStorage.setItem(
				"adminToken",
				token
			);

			alert("Admin Login Successful");

			window.location.href =
				"admin-dashboard.html";
		}
		else {

			alert(
				"Invalid Admin Credentials"
			);
		}
	}
	catch (error) {

		console.error(error);

		alert(
			"Unable to connect to server"
		);
	}
}