async function loadMenu() {

    const response =
        await fetch(
            "http://localhost:8083/admin/menu",
            {

        method:"GET",

        headers:{

            "Authorization":
                    "Bearer "
                    +
                    localStorage.getItem(
                            "adminToken")
        }
    }
        );

    const menu =
        await response.json();

    let html = "";

    menu.forEach(item => {

        let stockBadge = "";

        if (item.stock === 0) {

            stockBadge = `
                <span style="
                    position:absolute;
                    top:10px;
                    left:10px;
                    background:#dc3545;
                    color:white;
                    padding:5px 10px;
                    border-radius:20px;
                    font-size:12px;
                    font-weight:bold;">
                    Out of Stock
                </span>
            `;
        }
        else if (item.stock <= 5) {

            stockBadge = `
                <span style="
                    position:absolute;
                    top:10px;
                    left:10px;
                    background:#ffc107;
                    color:black;
                    padding:5px 10px;
                    border-radius:20px;
                    font-size:12px;
                    font-weight:bold;">
                    Low Stock (${item.stock})
                </span>
            `;
        }
        else {

            stockBadge = `
                <span style="
                    position:absolute;
                    top:10px;
                    left:10px;
                    background:#28a745;
                    color:white;
                    padding:5px 10px;
                    border-radius:20px;
                    font-size:12px;
                    font-weight:bold;">
                    In Stock (${item.stock})
                </span>
            `;
        }

        html += `

<div class="menu-card" style="position:relative;">

    ${stockBadge}

    <div class="menu-image">

        <img
            src="${item.image_src}"
            alt="${item.itemName}">

    </div>

    <div class="menu-content">

        <span class="category-badge">

            ${item.category}

        </span>

        <h3>

            ${item.itemName}

        </h3>

        <p class="description">

            ${item.description || ""}

        </p>

        <div class="price-row">

            <span class="price">

                ₹${item.price}

            </span>

        </div>

        <p style="margin-top:5px;font-weight:bold;color:#333;">
            📦 Stock: ${item.stock}
        </p>

        <button class="edit-btn"
            ${item.stock === 0 ? "disabled" : ""}
            onclick="editItem(${item.id},
                '${item.itemName}',
                '${item.category}',
                ${item.price},
                '${item.description}',
                '${item.image_src}',
                ${item.stock}
            )">

            Edit

        </button>

        <button
            class="delete-btn"
            onclick="deleteItem(${item.id})">

            Delete

        </button>

    </div>

</div>

`;
    });

    document
        .getElementById("menuList")
        .innerHTML = html;
}


/* ===========================
   ADD MENU
=========================== */

async function addMenu(){

    const itemId =
        document
        .getElementById("itemName")
        .getAttribute("data-id");

    const item = {

    itemName: document.getElementById("itemName").value.trim(),

    category: document.getElementById("category").value,

    price: parseFloat(document.getElementById("price").value),

    stock: parseInt(document.getElementById("stock").value),

    description: document.getElementById("description").value.trim(),

    image_src: document.getElementById("imageUrl").value.trim(),

    available: true
};
    try{

        if(itemId){

            await fetch(
                "http://localhost:8083/admin/menu/" + itemId,
                {
                    method:"PUT",
                   headers: {
                "Content-Type": "application/json"
            },

                    body: JSON.stringify(item)
                }
            );

            showToast("Menu Item Updated Successfully!");
        }
        else{

            await fetch(
                "http://localhost:8083/admin/menu",
                {
                    method:"POST",
                    headers: {
                "Content-Type": "application/json"
            },

                    body: JSON.stringify(item)
                }
            );

            showToast("Menu Item Added Successfully!");
        }

        document.getElementById("itemName").value = "";
        document.getElementById("category").value = "";
        document.getElementById("price").value = "";
        document.getElementById("stock").value = "";
        document.getElementById("description").value = "";
        document.getElementById("imageUrl").value = "";

        document.getElementById("itemName")
                .removeAttribute("data-id");

        loadMenu();

    }
    catch(error){

        console.error(error);
        showToast("Failed to save item..");
    }
}


/* ===========================
   UPDATE MENU
=========================== */

async function updateMenu(){

    const id =
        document.getElementById("updateId").value;

    const item = {

        id: id,

        itemName:
            document.getElementById("updateItemName").value,

        category:
            document.getElementById("updateCategory").value,

        price:
            parseFloat(
                document.getElementById("updatePrice").value
            ),

        stock:
            parseInt(
                document.getElementById("updateStock").value
            ),

        description:
            document.getElementById("updateDescription").value,

        image_src:
            document.getElementById("updateImageUrl").value
    };

    const response =
        await fetch(
            "http://localhost:8083/admin/menu/" + id,
            {
                method:"PUT",
                headers:{
                    "Content-Type":"application/json"
                },
                body: JSON.stringify(item)
            }
        );

    if(response.ok){

        showToast("Updated Successfully!");

        closeUpdateModal();

        loadMenu();
    }
    else{

        showToast("Updation Failed..");
    }
}


/* ===========================
   DELETE ITEM
=========================== */

async function deleteItem(id) {

    await fetch(
        "http://localhost:8083/admin/menu/" + id,
        {
            method: "DELETE",
            headers: {

                "Authorization":
                    "Bearer " +
                    localStorage.getItem("adminToken")
            }
        }
    );

    loadMenu();
}


/* ===========================
   EDIT ITEM
=========================== */

function editItem(
    id,
    itemName,
    category,
    price,
    description,
    imageSrc,
    stock
){

    document.getElementById("updateId").value = id;

    document.getElementById("updateItemName").value = itemName;

    document.getElementById("updateCategory").value = category;

    document.getElementById("updatePrice").value = price;

    document.getElementById("updateStock").value = stock;

    document.getElementById("updateDescription").value = description;

    document.getElementById("updateImageUrl").value = imageSrc;

    openUpdateModal();
}


/* ===========================
   MODALS
=========================== */

function openUpdateModal(){

    document.getElementById("updateModalOverlay")
            .style.display = "flex";
}

function closeUpdateModal(){

    document.getElementById("updateModalOverlay")
            .style.display = "none";
}

function goToAdminDashBoard2() {
    window.location.href = "admin-dashboard.html";
}