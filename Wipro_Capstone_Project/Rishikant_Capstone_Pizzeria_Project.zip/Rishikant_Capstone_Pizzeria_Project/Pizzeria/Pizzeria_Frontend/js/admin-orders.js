

let currentBillPdfBlob = null;
let currentOrderId = null;

async function loadOrders() {

	const response =
		await fetch(
			"http://localhost:8084/orders"
		);

	const orders =
		await response.json();

	let html = "";

	let pending = 0;
	let accepted = 0;

	orders.forEach(order => {

		if (order.status === "PENDING")
			pending++;

		if (order.status === "ACCEPTED")
			accepted++;

		html += `

        <div class="order-card">

            <div class="order-id">

                Order #${order.id}

            </div>

            <div class="order-info">

                👤 User ID :
                ${order.userId}

            </div>

            <div>

                <span class="status ${order.status.toLowerCase()}">

                    ${order.status}

                </span>

            </div>

            <div class="action-buttons">

                <button
                    class="accept-btn"
                    onclick="acceptOrder(${order.id})">

                    ✓ Accept

                </button>

                <button
                    class="reject-btn"
                    onclick="rejectOrder(${order.id})">

                    ✕ Reject

                </button>
                <button class="btn gnrt-btn"
    style="background:#f7e840;margin-top:10px;"
    onclick="generateBill(${order.id})">

    Generate Bill

</button>

            </div>

        </div>

        `;
	});

	document
		.getElementById("orders")
		.innerHTML = html;

	document
		.getElementById("totalOrders")
		.innerText = orders.length;

	document
		.getElementById("pendingOrders")
		.innerText = pending;

	document
		.getElementById("acceptedOrders")
		.innerText = accepted;
}



async function generateBill(orderId) {

    currentOrderId = orderId;

    try {

        const response = await fetch(
            "http://localhost:8085/billing/generate/" + orderId,
            {
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("token")
                }
            }
        );

        if (!response.ok) {
            alert("Failed to generate bill");
            return;
        }

        // ✅ IMPORTANT: parse JSON (NOT blob)
        const data = await response.json();

        console.log("Bill Data:", data);

        // store for download (we will still use pdf endpoint if needed later)
        window.currentBillData = data;

        // ✅ FILL POPUP FIELDS PROPERLY
        document.getElementById("b_orderId").innerText = data.orderId ?? "-";
        document.getElementById("b_subtotal").innerText = "₹ " + (data.subtotal ?? 0);
        document.getElementById("b_gst").innerText = "₹ " + (data.gst ?? 0);
        document.getElementById("b_delivery").innerText = "₹ " + (data.deliveryCharge ?? 0);
        document.getElementById("b_total").innerText = "₹ " + (data.totalAmount ?? 0);

        // show modal
        document.getElementById("billModal").style.display = "flex";

    } catch (error) {
        console.error(error);
        alert("Error generating bill");
    }
}
function downloadBill() {

    if (!currentBillBlob) {
        alert("No bill available");
        return;
    }

    const url = window.URL.createObjectURL(currentBillBlob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "invoice_" + currentOrderId + ".pdf";

    document.body.appendChild(a);
    a.click();

    document.body.removeChild(a);

    window.URL.revokeObjectURL(url);
}

function closeBillModal() {
	document.getElementById("billModal").style.display = "none";
}

async function acceptOrder(id) {

	await fetch(
		"http://localhost:8083/admin/orders/"
		+ id +
		"/accept",
		{
			method: "PUT",
			headers: {

                "Authorization":
                    "Bearer " +
                    localStorage.getItem("adminToken")
            }
		}
	);

	loadOrders();
}

async function rejectOrder(id) {

	await fetch(
		"http://localhost:8083/admin/orders/"
		+ id +
		"/reject",
		{
			method: "PUT",
			headers: {

                "Authorization":
                    "Bearer " +
                    localStorage.getItem("adminToken")
            }
		}
	);

	loadOrders();
}

function goToAdminDashBoard() {
	window.location.href = "admin-dashboard.html";
}