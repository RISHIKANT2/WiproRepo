const GATEWAY_URL =
	"http://localhost:8082";

async function registerUser() {

	const user = {

		name:
			document.getElementById("name").value,

		email:
			document.getElementById("email").value,

		password:
			document.getElementById("password").value
	};

	try {

		const response =
			await fetch(

				GATEWAY_URL +
				"/users/register",

				{

					method: "POST",

					headers: {
						"Content-Type":
							"application/json"
					},

					body:
						JSON.stringify(user)

				}
			);

		if (response.ok) {

			showToast("Registeration successful");

			window.location.href =
				"login.html";
		}
		else {

			const error =
				await response.text();

			showToast(error);;
		}

	}
	catch (error) {

		console.error(error);

		showToast("Server error");
	}
}

async function login() {

	const loginData = {

		email:
			document.getElementById(
				"loginEmail"
			).value,

		password:
			document.getElementById(
				"loginPassword"
			).value
	};

	try {

		const response =
			await fetch(

				GATEWAY_URL +
				"/users/login",

				{

					method: "POST",

					headers: {
						"Content-Type":
							"application/json"
					},

					body:
						JSON.stringify(loginData)
				}
			);

		if (response.ok) {

			const data =
				await response.json();

			localStorage.setItem(
				"token",
				data.token
			);
			
			localStorage.setItem(
                "userId",
               data.userId
              );
              console.log(data.userId);

			showToast("Login Successful");

			window.location.href =
				"menu.html";

		}
		else {

			showToast("Invalid Credentials ");
		}

	}
	catch (error) {

		console.error(error);

		showToast("Server Error");
	}
}

function logout() {

	localStorage.removeItem(
		"token"
	);

	window.location.href =
		"login.html";
}