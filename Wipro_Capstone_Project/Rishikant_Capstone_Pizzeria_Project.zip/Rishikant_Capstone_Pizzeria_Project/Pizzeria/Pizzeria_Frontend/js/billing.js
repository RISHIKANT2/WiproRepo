async function loadBill() {

    try {

        const orderId =
            localStorage.getItem("orderId");

        if (!orderId) {
            document.getElementById("billDetails").innerHTML =
                "<h3>No Order Found</h3>";
            return;
        }

        const response = await fetch(
            "http://localhost:8085/billing/generate/" + orderId
        );

        const bill = await response.json();

        // Save total for payment page
        localStorage.setItem(
            "totalAmount",
            bill.totalAmount
        );

        /* ===========================
           UPDATE SUMMARY PANEL
        =========================== */

        document.getElementById("subtotal").innerText =
            "₹" + bill.subtotal;

        document.getElementById("gst").innerText =
            "₹" + bill.gst;

        document.getElementById("total").innerText =
            "Total: ₹" + bill.totalAmount;

        /* ===========================
           BILL DETAILS (LEFT SIDE)
        =========================== */

        let html = "";

        html += `
        <div style="margin-bottom:20px;">
            <h2>Order ID: ${bill.orderId}</h2>
            <p style="color:gray;">Thank you for ordering from Pizzeria 🍕</p>
        </div>
        `;

        /* ===========================
           ITEM BREAKDOWN (if backend supports)
        =========================== */

        if (bill.items && bill.items.length > 0) {

            html += `<h3>Items</h3>`;

            bill.items.forEach(item => {

                html += `
                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:10px 0;
                    border-bottom:1px solid #eee;
                ">
                    <div>
                        <h4 style="margin:0;">${item.name || "Item"}</h4>
                        <p style="margin:0;color:gray;">
                            Qty: ${item.quantity}
                        </p>
                    </div>

                    <div>
                        ₹${item.price * item.quantity}
                    </div>
                </div>
                `;
            });
        }

        /* ===========================
           BILL SUMMARY INSIDE LEFT
        =========================== */

        html += `
        <div style="margin-top:20px;padding-top:10px;border-top:1px solid #ddd;">

            <p><b>Subtotal:</b> ₹${bill.subtotal}</p>
            <p><b>GST:</b> ₹${bill.gst}</p>
            <p><b>Delivery:</b> ₹${bill.deliveryCharge}</p>

            <h3>Total: ₹${bill.totalAmount}</h3>

        </div>
        `;

        document.getElementById("billDetails").innerHTML = html;

    }
    catch (error) {

        console.log(error);

        document.getElementById("billDetails").innerHTML =
            "<h3>Error loading bill</h3>";
    }
}

/* ===========================
   PAYMENT NAVIGATION
=========================== */

function goToPayment() {

    window.location.href = "payment.html";
}

function goToMenu() {
    window.location.href = "menu.html";
}