function getCart() {
    return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
}

/* =========================== LOAD CART =========================== */
function loadCart() {
    let cart = getCart();
    let html = "";
    let total = 0;

    if (cart.length === 0) {
        document.getElementById("cartItems").innerHTML = "<h3>Your cart is empty</h3>";
        document.getElementById("total").innerText = "Total: Rs 0";
        return;
    }

    cart.forEach((item, index) => {
        total += item.price * item.quantity;

        html += `

<div class="cart-item">

    <div>

        <h3>${item.itemName}</h3>

        <p>₹${item.price}</p>

        <p>
            Quantity :
            ${item.quantity}
        </p>

        <p
        style="
        color:#28a745;
        font-weight:bold;">

            Remaining :
            ${item.stock - item.quantity}

        </p>

    </div>

    <div>

        <button
            class="qty-btn"
            onclick="decreaseQty(${index})">

            -

        </button>

        <button
            class="qty-btn"
            ${item.quantity >= item.stock
                ? "disabled"
                : ""}
            onclick="increaseQty(${index})">

            +

        </button>

        <button
            class="remove-btn"
            onclick="removeItem(${index})">

            Remove

        </button>

    </div>

</div>

`;
    });

    document.getElementById("cartItems").innerHTML = html;
    document.getElementById("total").innerText = "Total: Rs " + total;
}

/* =========================== INCREASE QTY =========================== */
function increaseQty(index) {

    let cart = getCart();

    if (
        cart[index].quantity >=
        cart[index].stock
    ) {

        alert(
            `Only ${cart[index].stock} items available`
        );

        return;
    }

    cart[index].quantity++;

    saveCart(cart);

    loadCart();
}

/* =========================== DECREASE QTY =========================== */
function decreaseQty(index) {
    let cart = getCart();

    if (cart[index].quantity > 1) {
        cart[index].quantity--;
    } else {
        cart.splice(index, 1);
    }

    saveCart(cart);
    loadCart();
}

/* =========================== REMOVE ITEM =========================== */
function removeItem(index) {
    let cart = getCart();
    cart.splice(index, 1);
    saveCart(cart);
    loadCart();
}

function showSuccessPopup() {

    const popup =
        document.getElementById("successPopup");

    popup.classList.add("show");

    setTimeout(() => {

        popup.classList.remove("show");

        window.location.href =
            "billing.html";

    }, 4000);
}

/* =========================== PLACE ORDER =========================== */
async function placeOrder() {
    let cart = getCart();

    if (cart.length === 0) {
        showToast("Cart Empty");
        return;
    }

    const order = {
        userId: 1,
        deliveryMode: "HOME_DELIVERY",
        items: cart.map(item => ({
            menuItemId: item.id,
            quantity: item.quantity
        }))
    };

    try {
        const response = await fetch("http://localhost:8084/orders/place", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify(order)
        });

        if (response.ok) {

    const orderData =
        await response.json();

    localStorage.setItem(
        "orderId",
        orderData.id
    );

    showSuccessPopup();
} else {
            showToast("Order Failed");
        }

    } catch (error) {
        console.log(error);
        showToast("Something went wrong");
    }
}

/* =========================== NAVIGATION =========================== */
function goToMenu() {
    window.location.href = "menu.html";
}