function goToMenu() {

	window.location.href =
		"menu.html";
}

function goToCart() {

	window.location.href =
		"cart.html";
}

function logout() {

	localStorage.removeItem(
		"token"
	);

	window.location.href =
		"login.html";
}