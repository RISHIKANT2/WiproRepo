const API = "http://localhost:8083";

let allMenuItems = [];

/* =========================== CART INIT =========================== */
function getCart() {
    return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
}

/* =========================== UPDATE CART BADGE =========================== */
function updateCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);

    const badge = document.getElementById("cartCount");
    if (badge) {
        badge.innerText = count;
    }
}

/* =========================== LOAD MENU =========================== */
async function loadMenu() {
    try {
        const response = await fetch(API + "/admin/menu");
        const menu = await response.json();

        allMenuItems = menu;
        renderMenu(menu);
        updateCartCount();

    } catch (error) {
        console.log("Error loading menu:", error);
    }
}

/* =========================== RENDER MENU =========================== */
function renderMenu(items) {

    let html = "";

    const cart = getCart();

    items.forEach(item => {

        const cartItem =
            cart.find(c => c.id === item.id);

        const quantityInCart =
            cartItem ? cartItem.quantity : 0;

        const stockRemaining =
            item.stock - quantityInCart;

        html += `

        <div class="menu-card" style="position:relative;">

            <div
                style="
                position:absolute;
                top:10px;
                left:10px;
                background:#28a745;
                color:white;
                padding:6px 12px;
                border-radius:20px;
                font-size:12px;
                font-weight:bold;
                z-index:5;">
                Stock : ${stockRemaining}
            </div>

            <img
                src="${item.image_src}"
                alt="${item.itemName}">

            <div class="menu-content">

                <h3>${item.itemName}</h3>

                <p>${item.category}</p>

                <p>${item.description || ""}</p>

                <p class="price">
                    ₹${item.price}
                </p>

                <button
                    class="btn"
                    ${stockRemaining <= 0 ? "disabled" : ""}
                    onclick="addToCart(
                        ${item.id},
                        '${item.itemName}',
                        ${item.price},
                        ${item.stock}
                    )">

                    ${stockRemaining <= 0
                        ? "Out Of Stock"
                        : "Add To Cart"}

                </button>

            </div>

        </div>

        `;
    });

    document.getElementById("menu").innerHTML =
        html;
}
/* =========================== SEARCH =========================== */
function searchMenu() {
    const keyword = document
        .getElementById("searchInput")
        .value
        .toLowerCase()
        .trim();

    const filtered = allMenuItems.filter(item =>
        item.itemName.toLowerCase().includes(keyword) ||
        item.category.toLowerCase().includes(keyword) ||
        (item.description || "").toLowerCase().includes(keyword)
    );

    renderMenu(filtered);
}

/* =========================== CATEGORY FILTER =========================== */
function filterCategory(category) {
    if (category === "ALL") {
        renderMenu(allMenuItems);
        return;
    }

    const filtered = allMenuItems.filter(item =>
        item.category.toUpperCase() === category.toUpperCase()
    );

    renderMenu(filtered);
}

/* =========================== ADD TO CART =========================== */
function addToCart(
    id,
    name,
    price,
    stock
) {

    let cart = getCart();

    const existingItem =
        cart.find(
            item => item.id === id
        );

    if (existingItem) {

        if (
            existingItem.quantity >= stock
        ) {

            alert(
                `Only ${stock} items available`
            );

            return;
        }

        existingItem.quantity++;

    } else {

        cart.push({

            id: id,

            itemName: name,

            price: price,

            stock: stock,

            quantity: 1
        });
    }

    saveCart(cart);

    updateCartCount();

    renderMenu(allMenuItems);
}

/* =========================== NAVIGATION =========================== */
function goToCart() {
    window.location.href = "cart.html";
}

/* =========================== LOGOUT =========================== */
function logout() {
    localStorage.clear();
    window.location.href = "login.html";
}

/* =========================== INITIAL LOAD =========================== */
// IMPORTANT: remove duplicate onload conflict with HTML
// body already has onload="loadMenu()"