async function loadStatus() {

	const orderId =

		localStorage.getItem(
			"orderId"
		);

	const response =
		await fetch(

			"http://localhost:8084/orders/"
			+ orderId

		);

	const order =
		await response.json();

	document
		.getElementById(
			"status"
		)
		.innerText =
		order.status;

}