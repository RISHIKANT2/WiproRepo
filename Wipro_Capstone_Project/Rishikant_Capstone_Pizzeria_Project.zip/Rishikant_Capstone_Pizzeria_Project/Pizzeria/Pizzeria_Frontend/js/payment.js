window.onload = async function () {

    await loadUserInfo();

    loadOrderSummary();
};

async function loadUserInfo() {

    const userId =
        localStorage.getItem("userId");

    if (!userId) {

        console.error(
            "User Id not found in localStorage"
        );

        return;
    }

    try {

        const response =
            await fetch(
                `http://localhost:8086/payments/user/${userId}`
            );

        if (!response.ok) {

            throw new Error(
                "Unable to fetch user details"
            );
        }

        const user =
            await response.json();

        document.getElementById(
            "customerName"
        ).innerText =
            user.name || "N/A";

        document.getElementById(
            "customerPhone"
        ).innerText =
            user.phone || "N/A";

        document.getElementById(
            "customerAddress"
        ).innerText =
            user.address || "Address Not Available";

    }
    catch (error) {

        console.error(
            "User Fetch Error:",
            error
        );
    }
}

function loadOrderSummary() {

    const orderId =
        localStorage.getItem("orderId");

    const amount =
        parseFloat(
            localStorage.getItem(
                "totalAmount"
            )
        ) || 0;

    const deliveryFee = 40;

    const gst =
        amount * 0.08;

    const grandTotal =
        amount +
        gst +
        deliveryFee;

    const orderDisplay =
        document.getElementById(
            "orderIdDisplay"
        );

    if (orderDisplay) {

        orderDisplay.innerText =
            orderId;
    }

    const orderSummary =
        document.getElementById(
            "orderSummaryId"
        );

    if (orderSummary) {

        orderSummary.innerText =
            orderId;
    }

    document.getElementById(
        "subtotal"
    ).innerText =
        "₹" +
        amount.toFixed(2);

    document.getElementById(
        "gstAmount"
    ).innerText =
        "₹" +
        gst.toFixed(2);

    document.getElementById(
        "grandTotal"
    ).innerText =
        "₹" +
        grandTotal.toFixed(2);

    localStorage.setItem(
        "finalAmount",
        grandTotal.toFixed(2)
    );
}

async function makePayment() {

    const selectedPayment =
        document.querySelector(
            'input[name="payment"]:checked'
        );

    if (!selectedPayment) {

        alert(
            "Please select a payment method"
        );

        return;
    }

    const paymentMode =
        selectedPayment.value;

    const payment = {

        orderId:
            parseInt(
                localStorage.getItem(
                    "orderId"
                )
            ),

        amount:
            parseFloat(
                localStorage.getItem(
                    "finalAmount"
                )
            ),

        paymentMode:
            paymentMode
    };

    try {

        const response =
            await fetch(
                "http://localhost:8086/payments/pay",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            payment
                        )
                }
            );

        if (!response.ok) {

            throw new Error(
                "Payment Failed"
            );
        }

        const result =
            await response.json();

        localStorage.setItem(
            "paymentStatus",
            result.status
        );

        localStorage.setItem(
            "paymentMode",
            result.paymentMode
        );

        if (
            result.status === "SUCCESS"
        ) {

            alert(
                "Payment Successful 🎉"
            );

            window.location.href =
                "order-status.html";
        }
        else if (
            result.status === "PENDING"
        ) {

            alert(
                "Order Placed Successfully. Payment will be collected on delivery."
            );

            window.location.href =
                "order-status.html";
        }
        else {

            alert(
                "Payment Failed"
            );
        }
    }
    catch (error) {

        console.error(
            "Payment Error:",
            error
        );

        alert(
            "Unable to process payment. Please try again."
        );
    }
}
function goToMenu() {
    window.location.href = "menu.html";
}