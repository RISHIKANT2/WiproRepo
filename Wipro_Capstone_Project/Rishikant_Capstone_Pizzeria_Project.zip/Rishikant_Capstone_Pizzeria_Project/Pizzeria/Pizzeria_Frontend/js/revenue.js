

let chartInstance = null;

async function loadRevenue() {

    try {

        const revenueResponse =
            await fetch(
                "http://localhost:8085/billing/revenue/history"
            );

        const revenueData =
            await revenueResponse.json();

        console.log(revenueData);

        if (!Array.isArray(revenueData) || revenueData.length === 0) {

            document.getElementById("monthlyRevenue").innerText =
                "₹0";

            document.getElementById("monthName").innerText =
                "No Data";

            document.getElementById("yearValue").innerText =
                "";

            document.getElementById("insightText").innerText =
                "No revenue data available.";

            return;
        }

        // Calculate total revenue
        const totalRevenue =
            revenueData.reduce(
                (sum, item) =>
                    sum + (item.revenue || 0),
                0
            );

        document.getElementById("monthlyRevenue").innerText =
            "₹" + totalRevenue.toFixed(2);

        const monthNames = [

            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"

        ];

        const latestDate =
            new Date(
                revenueData[
                    revenueData.length - 1
                ].date
            );

        document.getElementById("monthName").innerText =
            monthNames[
                latestDate.getMonth()
            ];

        document.getElementById("yearValue").innerText =
            latestDate.getFullYear();

        document.getElementById("insightText").innerText =
            "Total revenue generated so far is ₹" +
            totalRevenue.toFixed(2) +
            ".";

        loadRevenueChart();

    }
    catch (error) {

        console.error(
            "Error loading revenue:",
            error
        );
    }
}

async function loadRevenueChart() {

    try {

        const response =
            await fetch(
                "http://localhost:8085/billing/revenue/history"
            );

        const data =
            await response.json();

        if (!Array.isArray(data) || data.length === 0) {
            return;
        }

        const labels =
            data.map(item => {

                const date =
                    new Date(item.date);

                return date.toLocaleDateString(
                    "en-IN",
                    {
                        day: "2-digit",
                        month: "short"
                    }
                );
            });

        const revenueValues =
            data.map(
                item => item.revenue
            );

        const ctx =
            document
                .getElementById(
                    "revenueChart"
                )
                .getContext("2d");

        if (chartInstance) {
            chartInstance.destroy();
        }

        chartInstance =
            new Chart(ctx, {

                type: "line",

                data: {

                    labels: labels,

                    datasets: [

                        {

                            label:
                                "Revenue (₹)",

                            data:
                                revenueValues,

                            borderColor:
                                "#ff3d00",

                            backgroundColor:
                                "rgba(255,61,0,0.2)",

                            fill: true,

                            tension: 0.4,

                            pointRadius: 5,

                            pointHoverRadius: 7

                        }

                    ]

                },

                options: {

                    responsive: true,

                    maintainAspectRatio: true,
                    aspectRatio: 2.5,

                    plugins: {

                        legend: {

                            display: true

                        }

                    },

                    scales: {

                        y: {

                            beginAtZero: true

                        }

                    }

                }

            });

    }
    catch (error) {

        console.error(
            "Error loading chart:",
            error
        );
    }
}

document.addEventListener(
    "DOMContentLoaded",
    loadRevenue
);