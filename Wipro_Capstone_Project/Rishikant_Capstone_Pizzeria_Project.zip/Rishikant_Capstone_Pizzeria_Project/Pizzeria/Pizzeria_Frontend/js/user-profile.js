window.onload = function () {

    const token = localStorage.getItem("token");
    const userId= localStorage.getItem("userId");
    // or localStorage.getItem("authToken")
    // depending on what name you used during login

    fetch("http://localhost:8082/users/"+userId, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        }
    })
    .then(res => {

        if (!res.ok) {
            throw new Error("Failed to fetch user details");
        }

        return res.json();
    })
    .then(data => {

        document.getElementById("name").innerText =
            data.name;

        document.getElementById("email").innerText =
            data.email;

       

        document.getElementById("role").innerText =
            data.role;

        document.getElementById("address").innerText =
            data.address || "Not set";
    })
    .catch(err => {
        console.error("Error:", err);
    });
};

// Update address
function updateAddress() {
    const userId= localStorage.getItem("userId");
    const token = localStorage.getItem("token");
    const newAddress = document.getElementById("newAddress").value;

    fetch("http://localhost:8082/users/address/"+userId, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({
            address: newAddress
        })
    })
    .then(res => res.text())
    .then(data => {
        const data1= JSON.parse(data.address);
        document.getElementById("address").innerText = data1;
        alert("Address updated successfully!");
    })
    .catch(err => console.error(err));
}